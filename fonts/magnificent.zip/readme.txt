Name: Magnificent 
Designer: Diego Vallejo 
Year: 2009 
Licence: Free for personal use 
Category: Serif 
Contains 212 characters in 9 ranges 
Version 1.002 2009 Copyright (c) Diego Vallejo, 2009. All rights reserved. Magnificent is a trademark of Diego Vallejo. 

For commercial use, contact me:
E-Mail/MSN: diego_vallejo_88@hotmail.com 
